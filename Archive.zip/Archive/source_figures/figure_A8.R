pacman::p_load(tidyverse)

rm(list = ls())

df <- read_csv("data/list_buildings.csv") %>%
    dplyr::distinct(add_full, .keep_all = T) %>%
    dplyr::select(
        year_constr_mode,
        rent_sqm_mean
    )

## Figure A.8

p1 <- df %>%
    ggplot(aes(x = year_constr_mode)) +
    geom_vline(xintercept = 2013.5, linetype = "dotted") +
    geom_bar(color = "black", fill = "grey95", width = 0.8) +
    theme_bw() +
    ylab("Number of apartments") +
    xlab("Apartment construction year") +
    scale_x_continuous(breaks = 2010:2017)
p1


#
